<template>
  <div style="padding: 5%">
    <b-form @submit="onSubmit" @reset="onReset" v-if="show">
      <b-form-group  label="Your Age:">
        <b-form-input
          v-model="form.age"
          required
          type="number"
          placeholder="Enter age"
        ></b-form-input>
      </b-form-group>
      <b-form-group  label="Your fnlwgt:">
        <b-form-input
          v-model="form.fnlwgt"
          required
              type="number"
          placeholder="Enter fnlwgt ( dinero en tu cuenta en entero)"
        ></b-form-input>
      </b-form-group>
      <b-form-group  label="Your educationNum:">
        <b-form-input
          v-model="form.educationNum"
          required
              type="number"
          placeholder="Enter educationNum (primaria:4, secundaria:7,poca universidad:9, universidad: 13, master:14, doc:15"
        ></b-form-input>
      </b-form-group>
      <b-form-checkbox
      id="checkbox-1"
      v-model="form.sex"
      name="checkbox-1"
      value="10"
      style="padding-bottom: 15px"
      unchecked-value="0"
    >
      Soy hombre
    </b-form-checkbox>
      <b-form-group  label="Your capitalGain:">
        <b-form-input
          v-model="form.capitalGain"
          required
              type="number"
          placeholder="Enter capitalGain por mes"
        ></b-form-input>
      </b-form-group>
      <b-form-group  label="Your capitalLoss:">
        <b-form-input
          v-model="form.capitalLoss"
          required
              type="number"
          placeholder="Enter capitalLoss"
        ></b-form-input>
      </b-form-group>
      <b-form-group  label="Your hours per week:">
        <b-form-input
          v-model="form.hours"
          required
              type="number"
          placeholder="Your hours per week"
        ></b-form-input>
      </b-form-group>
      <b-form-checkbox
      id="checkbox-2"
      v-model="form.Ke"
      name="checkbox-2"
      value=">50K"
      unchecked-value="<=50K"
    >
      Gano mas de 50K al anio
    </b-form-checkbox>
    <div style="padding-bottom: 15px"></div>
      <b-button type="submit" variant="primary">Submit</b-button>
      <b-button type="reset" variant="danger">Reset</b-button>
    </b-form>

    <b-card class="mt-3" header="Form Data Result">
      <pre class="m-0">{{ form }}</pre>
    </b-card>
  </div>
</template>

<script>
import axios from 'axios';

  export default {
    data() {
      return {
        form: {
          age: '',
    fnlwgt: "",
    educationNum: "",
    sex: "0",
    capitalGain: "",
    capitalLoss: "",
    hours: "",
    Ke: "<=50K",
        },
        show: true
      }
    },
    methods: {
      onSubmit(evt) {
        evt.preventDefault()
      axios
      .post('http://localhost:8000/knn',this.form,
      {headers: {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
    }})
      .then(response => (alert(response)))
      },
      onReset(evt) {
        evt.preventDefault()
        // Reset our form values
        this.form.age= '',
        this.form.fnlwgt= "",
        this.form.educationNum= "",
        this.form.sex= "",
        this.form.capitalGain= "",
        this.form.capitalLoss= "",
        this.form.hours= "",
        this.form.Ke= "",
        
      
        // Trick to reset/clear native browser form validation state
        this.show = false
        this.$nextTick(() => {
          this.show = true
        })
      }
    }
  }

</script>

<style>

</style>